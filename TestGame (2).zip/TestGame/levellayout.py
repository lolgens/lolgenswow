level_map = [
'                                                                                                                                                                                                                                                     XXXXX',
'                                                                                                                                                                                                                                                     XXXXX',
'X                                                                                                                                                                                                                                                    XXXXX',
'X                                                                                                                                                                                                                                                    XXXXX',
'X                                                                                                                                                                                                                                                      QXX',
'X                                                      XXX                                                                               XXXX                                                                                                          QXX',
'X                                    XXXX     XXX     XXXX                                                              XXXX     XXXX   XXXXXXXX                          XXXXX        X                                                               QXX',
'X      XXX              XXX          XXXX     XXX     XXXXX                        X    X                               XXXX     XXXX   XXXXXXXXXXXXXXXXXXXXXXX           XXXXX        XXXXXX                                                       XXXXXX',
'X    P         E       XXXXX         XXXX     XXX     XXXXXX           E           XE  EX                       XX                      XXXXXXXXXXXXXXXXXXXXXXXX           EEE         EEEE                                             XXXX        XXXXXX',
'X                    XXXXXXX         XXXX     XXX     XXXXXXX                      X    X                       XX                      XXXXXXXXXXXXXXXXXXXXXXXXXXX                                                 XXX       XXX       XXXX        XXXXXX',
'XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX             XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX     XXXXXX                      XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX                   XXX                   XXXXXX',
'XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX             XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX      XXXXXX                      XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX                   XXX                   XXXXXX',
'XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX     XXX     XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX          XXXXXX                      XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX                   XXX                   XXXXXX',
'XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX     XXX     XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX     XXXXXX                      XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX         XLX       XXX                   XXXXXX',
'JJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJ']



tilesize = 45
swid = 1024
shit = 630
print(shit)