level_map = [
'    I          I        I         I      I       I      I      I      I     I             I             I             I               I             I             I       XXXXX     I  XXXXXX        I                 I                  I                              XXXXX',
'                                                                                                                                                                          XXXXX        XXXXXX                                                        XXXXX',
'X                                                                                                                                                                         XXXXX        XXXXXX                                                        XXXXX',
'X                                                                                                                                                                         XXXXX        XXXXXX                                                        XXXXX',
'X                                                                                                                                                                         XXXXX        XXXXXX                                                          QXX',
'X                                                     XXX                                                                               XXXX                              XXXXX        XXXXXX                                                          QXX',
'X                                    XXXX     XXX     XXXX                                                              XXXX     XXXX   XXXXXXXX                          XXXXX        XXXXXX                                                          QXX',
'X      XXX              XXX          XXXX     XXX     XXXXX                        X    X                               XXXX     XXXX   XXXXXXXXXXXXXXXXXXXXXXX                                                                                     XXXXXX',
'X    P         E       XXXXX         XXXX     XXX     XXXXXX           E           XE  EX                       XX                      XXXXXXXXXXXXXXXXXXXXXXXX           EEE         EEEE                                             XXXX        XXXXXX',
'X                    XXXXXXX         XXXX     XXX     XXXXXXX                      X    X                       XX                      XXXXXXXXXXXXXXXXXXXXXXXXXXX                                                 XXX       XXX       XXXX        XXXXXX',
'XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX             XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX     XXXXXX                      XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX                   XXX                   XXXXXX',
'XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX             XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX      XXXXXX                      XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX                   XXX                   XXXXXX',
'XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX     XXX     XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX          XXXXXX                      XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX                   XXX                   XXXXXX',
'XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX     XXX     XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX     XXXXXX                      XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX         XLX       XXX                   XXXXXX',
'JJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJ']



tilesize = 45
swid = 1024
shit = 630
print(shit)