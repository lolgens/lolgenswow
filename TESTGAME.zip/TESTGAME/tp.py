import pygame

class pole(pygame.sprite.Sprite):
	def __init__(self,pos):
		super().__init__()
		self.image = pygame.Surface((60,700))
		self.image.fill('dimgray')
		self.rect = self.image.get_rect(topleft=pos)

	def update(self,x_shift):
		if self.rect.x > 20:
			self.rect.x += x_shift
		else: 
			self.rect.x += x_shift*2	