
import pygame
import time
import random
import sys
from levellayout import *
from levellayout2 import*
from level1 import Level
from player import Player
from os import path
pygame.init()
clock = pygame.time.Clock()
win = pygame.display.set_mode((swid,shit))
pygame.display.set_caption('game2')
def Highscore():
	global highscore
	player = level.player.sprite
	joe = font.render(f'HIGHSCORE: {int(highscore)}',1,'white')
	win.blit(joe,(350,60))	
def load():
	global direct
	global highscore
	direct = path.dirname(__file__)
	with open(path.join(direct,hsfile),'r') as f:
		try:
			highscore = int(f.read())
		except:
			highscore = 0	

def scorecounter():
	global highscore
	player = level.player.sprite
	joe = font.render(f'SCORE: {player.score}',1,'white')
	if player.score > highscore and level.level == 4:
		highscore = player.score 
	win.blit(joe,(400,2))
class wavetimer():
		
	    def __init__(self,cooldown):
	        pygame.sprite.Sprite.__init__(self)
	        self.cooldown = cooldown 
	        self.timer = cooldown * 1000
	        self.bulletfired = False 
	    def waveti(self):
	        self.timer -= dt  
	        player = level.player.sprite
	        joe = font.render('Wave in'+str(int((self.timer)/1000)+1),1,'white')
	        joe2 = font.render('Fire!!',1,'white')
	        if self.timer > 0:
	        	win.blit(joe,(2,2))
	        if self.timer <=0 :
	        	win.blit(joe2,(2,2))
	        key = pygame.key.get_pressed()
        	if key[pygame.K_e] and self.timer <= 0 and self.bulletfired == False:
        		player = level.player.sprite
        		if player.left: 
        			level.bullets.add(player.bullcreate(-1))
        		if player.right:
        			level.bullets.add(player.bullcreate(1))	
        		self.bulletfired = True
        		self.timer = 2000

        	if key[pygame.K_e] == False:
        		self.bulletfired = False	
def debug():
	player = level.player.sprite
	joe = font.render(f'x={player.rect.x},y={player.rect.y}',1,'white')
	joe2 = font.render(f'x={player.rect2.x},y={player.rect2.y}',1,'white')
	win.blit(joe,(300,300))
	win.blit(joe2,(300,500))    
def start():
	global run 
	title = font.render('Test',1,'white')
	play = font.render('Press any key to play',1,'white')
	win.blit(title, (450,10))
	win.blit(play,(325,300))
	pygame.display.flip()
	waiting = True
	while waiting:
		for event in pygame.event.get():
			if event.type == pygame.QUIT:
				sys.exit()
				run = False 
				waiting = False
			if event.type == pygame.KEYUP:
			 	menu()
			 	waiting = False	
	pygame.quit()
def gameend():
	win.fill('black')
	level2.level =2
	level.level = 1
	level.gameoverstat = False
	title = font.render('Test',1,'white')
	play = font.render('Press any key to play',1,'white')
	win.blit(title, (450,10))
	win.blit(play,(325,300))
	pygame.display.flip()
	waiting = True
	while waiting:
		for event in pygame.event.get():
			if event.type == pygame.QUIT:
				sys.exit()
				run = False
				waiting = False
			if event.type == pygame.KEYUP:
			 	menu()
			 	waiting = False	

	pygame.quit()	
y = 210
def credits():
	while credits:
		info = font.render('Game made by me',1,'white')	
		back = font.render('Press Z to go back',1,'white')	

def menu():
	y = 210
	state = 1
	menu = True
	while menu:
		global run
		win.fill('black')
		x = 275
		title = font.render('Menu test',1,'white')
		play = font.render('Start',1,'white')
		creds = font.render('Credits',1,'white')
		options = font.render('Options',1,'white')
		cursor = font.render('*',1,'white')
		lmao = font.render(str(state),1,'white')
		Highscore()
		win.blit(title, (400,10))
		win.blit(play,(325,200))
		win.blit(creds, (325,300))
		win.blit(options,(325,400))
		for event in pygame.event.get():
			if event.type == pygame.QUIT:
				sys.exit()
				run = False
				menu = False 
			

			if event.type == pygame.KEYDOWN:
				if event.key == pygame.K_DOWN:
					if y <400:
						y += 100
						state += 1
				if event.key == pygame.K_UP:
					if y > 210:
						y -= 100
						state -=1
			if event.type == pygame.KEYDOWN:
				if event.key == pygame.K_RETURN and state == 1:
					menu = False 
					run = True
					main()
				if event.key == pygame.K_RETURN and state == 2:
					menu = False

		win.blit(lmao,(1,1))						
		win.blit(cursor,(x,y))
		pygame.display.update()	
	pygame.quit()
def reminder():
	player = level.player.sprite
	joe = font.render('You must go thru all the portals',1,'white')	
	for sprite in level.endportal.sprites():
		if sprite.rect.colliderect(player.rect):
			if level.level <3:
				win.blit(joe,(200,2))				
hsfile = 'highscore.txt'				
font = pygame.font.SysFont('Calibri',50)
level = Level(level_map,win,1)
level2 = Level(level_map2,win,2)
wavetim = wavetimer(2)
load()
run = True
def main():
	global run
	global level
	global level2
	global dt
	global highscore 
	while run:
		player = level.player.sprite
		dt = clock.tick(60)	
		for event in pygame.event.get():
			if event.type == pygame.QUIT:
				sys.exit()
				menu = False
				
		win.fill('black')
		if level.level == 1:
			wavetim.waveti()
			level.run()
		if level.level == 2:
			level2.run()
		if level2.level ==3:
			level.level = 3 
			level.run()	
		if level.level ==4:
			if player.score > highscore:
				highscore = player.score
				with open(path.join(direct,hsfile),'w') as f:
					f.write(str(player.score)) 	
			level = Level(level_map,win,1)
			level2 = Level(level_map2,win,2)
			time.sleep(1)
			gameend()
		if level.gameoverstat == True:

			level = Level(level_map,win,1)
			level2 = Level(level_map2,win,2)
			run = False
			gameend()
			level.gameoverstat = False  
		if level2.gameoverstat == True:
			level = Level(level_map,win,1)
			level2 = Level(level_map2,win,2)
			gameend()
			run = False
			level.gameoverstat = False 
		scorecounter()		
		reminder()
		pygame.display.update()
	pygame.quit()	

start()
